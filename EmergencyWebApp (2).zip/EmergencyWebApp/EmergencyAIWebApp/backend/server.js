// Node.js + Express.js server setup
// server.js

import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import bodyParser from 'body-parser';
import cors from 'cors';

import { sendEmergencyEmail } from './backend/utils/sendEmail.js';
import { triggerEmergencyCall } from './backend/utils/triggerCall.js';

const app = express();
const PORT = process.env.PORT || 5000;

// For resolving __dirname in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'frontend')));

// 📩 Email Endpoint
app.post('/api/send-email', async (req, res) => {
  const { to, subject, message } = req.body;
  try {
    await sendEmergencyEmail(to, subject, message);
    res.status(200).json({ success: true, message: 'Email sent' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 📞 Call Endpoint
app.post('/api/trigger-call', async (req, res) => {
  const { phone, message } = req.body;
  try {
    const result = await triggerEmergencyCall(phone, message);
    if (result.success) {
      res.status(200).json({ success: true, sid: result.sid });
    } else {
      res.status(500).json({ success: false, error: result.error });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 🚀 Start Server
app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
