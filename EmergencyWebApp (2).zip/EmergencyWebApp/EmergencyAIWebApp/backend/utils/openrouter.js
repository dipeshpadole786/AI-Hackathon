// Utility function to query OpenRouter GPT
// OpenRouter.js
import axios from 'axios';

const OPENROUTER_API_KEY =  "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"; // Replace with your actual key
const MODEL_NAME = 'gpt-4o'; // You can change to 'mistral-7b', 'claude-3-haiku', etc.

export async function fetchAIReply(userMessage) {
  try {
    const response = await axios.post(
      'https://openrouter.ai/api/v1/chat/completions',
      {
        model: MODEL_NAME,
        messages: [
          {
            role: 'system',
            content:
              'You are a helpful, multilingual assistant that always replies in the same language as the user.'
          },
          {
            role: 'user',
            content: userMessage
          }
        ]
      },
      {
        headers: {
          'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const aiReply = response.data.choices[0].message.content.trim();
    return aiReply;
  } catch (error) {
    console.error('❌ OpenRouter API error:', error.message);
    return 'Sorry, I am unable to respond right now.';
  }
}
