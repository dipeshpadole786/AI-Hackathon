// Utility function for ElevenLabs TTS
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const ELEVENLABS_API_KEY ='sk_6c0bce1c95fb0d8f56f8d4be903ef65dc4cc7efe73722c32';
const VOICE_ID = '21m00Tcm4TlvDq8ikWAM'; // 🔊 Default voice (Rachel). You can change this.

const generateSpeech = async (text, filename = 'output.mp3') => {
  try {
    const response = await axios.post(
      `https://api.elevenlabs.io/v1/text-to-speech/${VOICE_ID}`,
      {
        text,
        model_id: 'eleven_monolingual_v1', // or try 'eleven_multilingual_v2'
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.75
        }
      },
      {
        headers: {
          'xi-api-key': ELEVENLABS_API_KEY,
          'Content-Type': 'application/json',
          'Accept': 'audio/mpeg'
        },
        responseType: 'stream'
      }
    );

    const outputPath = path.join(__dirname, '../../public/audio', filename);
    const writer = fs.createWriteStream(outputPath);
    response.data.pipe(writer);

    return new Promise((resolve, reject) => {
      writer.on('finish', () => {
        console.log('✅ Voice audio saved at:', outputPath);
        resolve(`/audio/${filename}`);
      });
      writer.on('error', reject);
    });

  } catch (err) {
    console.error('❌ ElevenLabs TTS error:', err.message);
    throw err;
  }
};

module.exports = { generateSpeech };
