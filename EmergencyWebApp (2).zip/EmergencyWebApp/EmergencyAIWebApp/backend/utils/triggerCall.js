const twilio = require("twilio");
require("dotenv").config();

const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const fromPhone = process.env.TWILIO_PHONE_NUMBER;

const client = twilio(accountSid, authToken);

const makeCall = (toPhone) => {
  return client.calls.create({
    url: "http://demo.twilio.com/docs/voice.xml",  // Default Twilio voice message
    to: toPhone,
    from: fromPhone,
  });
};

module.exports = makeCall;
