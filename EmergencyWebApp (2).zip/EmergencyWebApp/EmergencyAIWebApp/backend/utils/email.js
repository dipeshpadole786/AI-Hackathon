const nodemailer = require('nodemailer');

const sendAlertEmail = async ({ name, location, message }) => {
  try {
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'pantawaneraunak@gmail.com',           // 🔐 Your Gmail
        pass: 'Ittalian',        // 🔐 Gmail App Password
      },
    });

    const mailOptions = {
      from: '"Emergency AI System" <pantawaneraunak@gmail.com>',
      to: '24070140@ycce.in',             // 👨‍⚕️ Doctor, family, or hospital email
      subject: '🚨 Emergency Alert Detected!',
      html: `
        <h2>🚨 Emergency Detected!</h2>
        <p><strong>Name:</strong> ${name || 'Unknown'}</p>
        <p><strong>Location:</strong> ${location || 'Not provided'}</p>
        <p><strong>Details:</strong> ${message || 'No message'}</p>
        <p>Time: ${new Date().toLocaleString()}</p>
        <p><i>Please respond immediately.</i></p>
      `,
    };

    await transporter.sendMail(mailOptions);
    console.log('✅ Emergency email sent!');
  } catch (error) {
    console.error('❌ Email sending failed:', error.message);
  }
};

module.exports = { sendAlertEmail };
