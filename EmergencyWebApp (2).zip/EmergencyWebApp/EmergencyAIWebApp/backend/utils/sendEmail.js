// Utility function to send email alerts
// backend/utils/sendEmail.js
import nodemailer from 'nodemailer';
import { sendEmergencyEmail } from './backend/utils/sendEmail.js';


export async function sendEmergencyEmail(toEmail, subject, message) {
  try {
    // Configure the transporter (using Gmail SMTP)
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'pantawaneraunak@gmail.com', // Replace with your Gmail
        pass: 'Ittalian'     // Use App Password (not your Gmail password)
      }
    });

    const mailOptions = {
      from: 'pantawaneraunak@gmail.com',
      to: '24070140@ycce.in',
      subject: 'For Ambulance',
      text: 'I want ambulance right now.'
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('✅ Email sent: ', info.response);
    return true;
  } catch (error) {
    console.error('❌ Error sending email: ', error);
    return false;
  }
}
