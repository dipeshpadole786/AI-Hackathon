// Route to handle email sending via SMTP.js or Gmail API
const express = require('express');
const router = express.Router();
const { sendAlertEmail } = require('../utils/email');

router.post('/send-email', async (req, res) => {
  const { name, location, message } = req.body;

  try {
    await sendAlertEmail({ name, location, message });
    res.status(200).json({ success: true, msg: 'Email sent' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
