// routes/call.js
const express = require("express");
const router = express.Router();
const makeCall = require("../utils/triggerCall");

router.post("/call", async (req, res) => {
  try {
    const call = await makeCall();
    res.status(200).json({ message: "Call initiated!", sid: call.sid });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "Failed to initiate call", error });
  }
});

module.exports = router;
