// Route to handle OpenRouter GPT AI logic
const express = require('express');
const router = express.Router();
const getOpenRouterReply = require('../utils/openrouter');

router.post('/', async (req, res) => {
  const { prompt } = req.body;
  try {
    const reply = await getOpenRouterReply(prompt);
    res.json({ reply });
  } catch (err) {
    console.error('AI Error:', err.message);
    res.status(500).json({ error: 'AI response failed' });
  }
});

module.exports = router;
