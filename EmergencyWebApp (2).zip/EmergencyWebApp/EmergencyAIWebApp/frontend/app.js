const startBtn = document.getElementById("startBtn");
const userInput = document.getElementById("userInput");
const aiResponse = document.getElementById("aiResponse");
const locationBox = document.getElementById("location");
const callNow = document.getElementById("callNow");

const emergencyKeywords = ["help", "emergency", "fire", "accident", "danger", "i need help"];

// Text to Speech
function speak(text) {
  const synth = window.speechSynthesis;
  const utter = new SpeechSynthesisUtterance(text);
  synth.speak(utter);
}

// Voice Input Setup
const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
recognition.lang = 'en-US';

startBtn.onclick = () => {
  recognition.start();
};

recognition.onresult = (event) => {
  const transcript = event.results[0][0].transcript.toLowerCase();
  userInput.innerText = transcript;
  aiResponse.innerText = "Analyzing...";

  if (emergencyKeywords.some(word => transcript.includes(word))) {
    aiResponse.innerText = "Emergency detected! Taking action...";
    speak("Emergency detected. Help is on the way!");
    triggerCall();
    sendAlertEmail(transcript);
  } else {
    aiResponse.innerText = "No emergency detected.";
    speak("I did not detect an emergency.");
  }
};

recognition.onerror = (e) => {
  aiResponse.innerText = "Speech Error: " + e.error;
};

// Trigger emergency call
function triggerCall() {
  const phone = "+911234567890"; // Replace with your emergency contact
  callNow.href = `tel:${phone}`;
  callNow.style.display = "block";
  callNow.click();
}

// Send email alert
function sendAlertEmail(message) {
  fetch("/send-alert", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      subject: "🚨 Emergency Alert",
      body: `Message: ${message}\nLocation: ${locationBox.innerText}`,
    })
  })
  .then(res => res.json())
  .then(data => {
    console.log("Email Sent:", data.status);
  })
  .catch(err => {
    console.error("Email Error:", err);
  });
}

// Detect location
fetch("https://ipapi.co/json")
  .then(res => res.json())
  .then(data => {
    locationBox.innerText = `${data.city}, ${data.region}, ${data.country_name}`;
  })
  .catch(() => {
    locationBox.innerText = "Unknown";
  });
